import asyncio
from playwright.async_api import Playwright, async_playwright

import csv

